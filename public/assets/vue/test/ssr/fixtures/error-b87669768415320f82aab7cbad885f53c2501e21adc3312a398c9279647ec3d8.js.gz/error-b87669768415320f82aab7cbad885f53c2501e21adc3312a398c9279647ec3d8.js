throw new Error('foo')
;
